# Prototype UX — gestion de copropriété (version multi-pages)

Prototype navigable en HTML/CSS/JS vanilla, sans build ni dépendance
(hors polices Google, qui dégradent proprement si elles ne chargent pas).

## Lancer

Ouvrir `index.html` dans un navigateur. Un serveur statique n'est pas
nécessaire, mais recommandé pour éviter les restrictions `file://` :

    python3 -m http.server 8000

## Arborescence

    index.html                brief + sélection du cas de figure + plan
    connexion.html            connexion et résolution du contexte d'arrivée
    accueil.html              tableau de bord (copropriétaire ou bureau)
    lots.html / lot.html      espace copropriétaire — patrimoine
    echeances.html            espace copropriétaire — appels de fonds
    paiements.html            espace copropriétaire — historique et reçus
    messagerie.html           transverse — boîte de réception
    fil.html                  transverse — fil de discussion
    nouveau-message.html      transverse — rédaction, choix du canal
    notifications.html        transverse — liste globale
    profil.html               transverse — compte, biens, mandats
    ma-copro.html             espace bureau — infos / lots / configuration
    syndic-echeances.html     espace bureau — recouvrement
    comptabilite.html         espace bureau — budget et écritures
    matrice.html              documentation — conditionnement des écrans
    assets/app.css            jetons de design + composants
    assets/app.js             modèle, écrans, routeur

## Règle d'arrivée

Deux règles, dans cet ordre, appliquées par `landing()` :

1. L'espace par défaut est `copro` dès que la personne détient au moins un
   lot, y compris pour un président de bureau. Un mandat s'assume, il ne
   s'impose pas ; la charge de mandat est signalée par une carte sur l'écran
   d'arrivée, jamais par une bascule.
   Sans lot (gérant professionnel, cas 8), l'espace `copro` n'existe pas :
   on entre par `syndic` sur le premier mandat, dans un ordre stable. Les
   pages `lots`, `lot`, `echeances` et `paiements` redirigent alors vers
   `accueil.html`.
2. L'écran d'arrivée est **toujours** `accueil.html`, quel que soit l'état
   du compte. Aucune résolution selon la criticité : un point d'entrée
   constant s'apprend, un point d'entrée variable se subit.

## État de navigation

Tout l'état porté par l'URL, ce qui rend le routage lisible et rejouable :

    lots.html?cas=c7&space=copro
    ma-copro.html?cas=c7&space=syndic&ctx=atlas&tab=lots
    fil.html?cas=c4&space=syndic&ctx=atlas&id=fb0

- `cas`   : persona simulé (`c1` à `c7`)
- `space` : `copro` (consolidé, tous biens) ou `syndic` (scopé à une résidence)
- `ctx`   : identifiant de résidence, requis quand `space=syndic`
- `id`, `tab` : paramètres d'écran

Les micro-interactions (filtres, onglets, feuilles modales, rédaction)
restent locales à la page et ne changent pas l'URL.

Les messages envoyés sont conservés en `sessionStorage` le temps de la
session, pour que l'envoi reste visible après changement de page.

## Passage à React

Le découpage anticipe la migration :

- `RES`, `CASES`, `buildEcheances/Paiements/Fils/Notifs` → couche données
- `channels()`, `defaultChannelId()`, `visibleFil()`, `spaces()` → règles métier
  d'affichage, à extraire telles quelles en hooks ou sélecteurs
- une fonction `*HTML()` par écran → un composant
- `PAGEMAP` / `FILEOF` → table de routes
